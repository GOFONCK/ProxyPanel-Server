# Настройка Xray ноды

Это руководство поможет вам настроить и запустить ноду с интеграцией Xray.

## Что такое Xray?

Xray - это мощный прокси-сервер, поддерживающий множество протоколов:
- **VMess** - основной протокол Xray
- **VLESS** - облегченный протокол без шифрования
- **Trojan** - протокол, маскирующийся под HTTPS
- **Shadowsocks** - классический протокол
- **SOCKS5** - стандартный SOCKS5 прокси

## Варианты интеграции

### Вариант 1: Xray как SOCKS5 прокси (рекомендуется)

Самый простой способ - настроить Xray для работы как SOCKS5 прокси, а затем подключить к нему нашу ноду.

#### Шаг 1: Установка Xray

**macOS:**
```bash
brew install xray
```

**Linux:**

**Вариант 1: С использованием unzip (рекомендуется)**
```bash
# Установите unzip если его нет
sudo apt-get update && sudo apt-get install -y unzip  # Для Debian/Ubuntu
# или
sudo yum install -y unzip  # Для CentOS/RHEL
# или
sudo dnf install -y unzip  # Для Fedora

# Скачайте последнюю версию с GitHub
wget https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip
unzip Xray-linux-64.zip
sudo mv xray /usr/local/bin/
sudo chmod +x /usr/local/bin/xray
```

**Вариант 2: Без unzip (используя Python или другие инструменты)**
```bash
# Установите Python если его нет
sudo apt-get install -y python3 python3-pip  # Для Debian/Ubuntu

# Скачайте архив
wget https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip

# Распакуйте с помощью Python
python3 -m zipfile -e Xray-linux-64.zip /tmp/xray-extract/
sudo mv /tmp/xray-extract/xray /usr/local/bin/
sudo chmod +x /usr/local/bin/xray
rm -rf /tmp/xray-extract Xray-linux-64.zip
```

**Вариант 3: Скачать напрямую без распаковки архива**
```bash
# Для некоторых систем доступны tar.gz архивы
wget https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.tar.gz
tar -xzf Xray-linux-64.tar.gz
sudo mv xray /usr/local/bin/
sudo chmod +x /usr/local/bin/xray
rm -rf Xray-linux-64.tar.gz geoip.dat geosite.dat
```

**Вариант 4: Использование установщика (для некоторых дистрибутивов)**
```bash
# Для Debian/Ubuntu можно использовать установщик
bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install
```

**Windows:**
Скачайте с [GitHub Releases](https://github.com/XTLS/Xray-core/releases)

#### Шаг 2: Создание конфигурации Xray

Создайте файл `xray_config.json`:

```json
{
  "log": {
    "loglevel": "warning"
  },
  "inbounds": [
    {
      "port": 10808,
      "protocol": "socks",
      "settings": {
        "auth": "noauth",
        "udp": true
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
```

Этот конфиг создаст SOCKS5 прокси на порту `10808`.

#### Шаг 3: Запуск Xray

```bash
xray run -config xray_config.json
```

#### Шаг 4: Настройка ноды

Откройте `xray_node.py` и настройте:

```python
# Адрес Xray SOCKS5 прокси
XRAY_SOCKS5_HOST = '127.0.0.1'
XRAY_SOCKS5_PORT = 10808

# Режим работы
XRAY_MODE = 'socks5'

# Автоматический запуск Xray (если нужно)
AUTO_START_XRAY = False  # Установите True, если хотите автоматический запуск
```

#### Шаг 5: Запуск ноды

```bash
python3 xray_node.py
```

### Вариант 2: Использование существующего Xray сервера

Если у вас уже есть Xray сервер с VMess/VLESS/Trojan, вы можете:

1. **Настроить Xray с SOCKS5 inbound** - добавьте в конфиг Xray:

```json
{
  "inbounds": [
    {
      "port": 10808,
      "protocol": "socks",
      "settings": {
        "auth": "noauth"
      }
    },
    {
      "port": 443,
      "protocol": "vmess",
      "settings": {
        "clients": [...]
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom"
    }
  ],
  "routing": {
    "rules": [
      {
        "type": "field",
        "inboundTag": ["socks"],
        "outboundTag": "direct"
      }
    ]
  }
}
```

2. **Подключить ноду к SOCKS5 порту** - нода будет проксировать трафик через ваш Xray сервер.

### Вариант 3: Автоматический запуск Xray с вашей JSON конфигурацией

Если вы хотите использовать свою собственную JSON конфигурацию Xray (например, с VLESS-TCP-REALITY):

1. Создайте файл конфигурации Xray в формате JSON (например, `xray_config.json`):

```json
{
  "log": {
    "loglevel": "none"
  },
  "inbounds": [
    {
      "tag": "VLESS_TCP_REALITY_testt",
      "port": 450,
      "listen": "0.0.0.0",
      "protocol": "vless",
      "settings": {
        "clients": [],
        "decryption": "none"
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls", "quic"]
      },
      "streamSettings": {
        "network": "raw",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "xver": 0,
          "target": "yahoo.com:443",
          "shortIds": [""],
          "privateKey": "ваш_приватный_ключ",
          "serverNames": ["yahoo.com", "www.yahoo.com"]
        }
      }
    }
  ],
  "outbounds": [
    {
      "tag": "DIRECT",
      "protocol": "freedom"
    },
    {
      "tag": "SHADOWSOCKS_REMOTE",
      "protocol": "shadowsocks",
      "settings": {
        "servers": [
          {
            "port": 990,
            "method": "chacha20-ietf-poly1305",
            "address": "212.102.54.45",
            "password": "ARgvGZywA+gacgGV26Bvmu05+wZmRW/j+AdU+Z8Bt44="
          }
        ]
      }
    }
  ],
  "routing": {
    "rules": [
      {
        "type": "field",
        "network": "tcp,udp",
        "inboundTag": ["VLESS_TCP_REALITY_testt"],
        "outboundTag": "SHADOWSOCKS_REMOTE"
      }
    ]
  }
}
```

**Важно:** 
- Нода автоматически добавит SOCKS5 inbound на порту `10808` (по умолчанию), если его нет в вашем конфиге. Это необходимо для работы ноды.
- Для REALITY протокола **обязательно нужен** `privateKey`. См. инструкцию по генерации ключей в `REALITY_KEYS_GUIDE.md`

2. Настройте `xray_node.py`:

```python
AUTO_START_XRAY = True
XRAY_BINARY_PATH = '/usr/local/bin/xray'  # Путь к Xray
XRAY_CONFIG_PATH = 'xray_config.json'  # Путь к вашему JSON конфигу
XRAY_SOCKS5_PORT = 10808  # Порт SOCKS5 inbound (будет добавлен автоматически если отсутствует)
```

3. Запустите ноду:

```bash
python3 xray_node.py
```

Нода автоматически:
- Загрузит вашу JSON конфигурацию
- Добавит SOCKS5 inbound для работы ноды (если его нет)
- Запустит Xray с этой конфигурацией
- Будет проксировать трафик через ваш Xray сервер

#### Где создавать конфиг?

**Важно:** Не создавайте конфиг в `/usr/local/bin/` — там находятся исполняемые файлы!

**Рекомендуемые места для конфига:**

1. **В директории проекта ноды** (рекомендуется):
```bash
# Перейдите в директорию где находится xray_node.py
cd /path/to/proxypanel

# Создайте конфиг там
nano xray_config.json

# В xray_node.py укажите:
XRAY_CONFIG_PATH = 'xray_config.json'  # или полный путь
```

2. **В стандартной директории для конфигов**:
```bash
# Создайте директорию для конфигов Xray
sudo mkdir -p /usr/local/etc/xray

# Создайте конфиг там
sudo nano /usr/local/etc/xray/config.json

# В xray_node.py укажите:
XRAY_CONFIG_PATH = '/usr/local/etc/xray/config.json'
```

3. **В домашней директории**:
```bash
# Создайте конфиг в домашней директории
nano ~/xray_config.json

# В xray_node.py укажите:
XRAY_CONFIG_PATH = '/root/xray_config.json'  # или ~/xray_config.json (если запускается от root)
```

#### Использование готового примера

Вы можете использовать файл `xray_config_example.json` как шаблон:

```bash
# Перейдите в директорию проекта
cd /path/to/proxypanel

# Скопируйте пример
cp xray_config_example.json xray_config.json

# Отредактируйте под свои нужды
nano xray_config.json

# В xray_node.py укажите относительный путь:
XRAY_CONFIG_PATH = 'xray_config.json'
# или абсолютный путь:
# XRAY_CONFIG_PATH = '/path/to/proxypanel/xray_config.json'
```

## Установка зависимостей

### Важно: Виртуальное окружение

Если вы получили ошибку `externally-managed-environment`, используйте виртуальное окружение (рекомендуется):

```bash
# Создайте виртуальное окружение
python3 -m venv venv

# Активируйте его
source venv/bin/activate

# Установите зависимости
pip install -r requirements.txt

# Теперь запускайте ноду
python3 xray_node.py

# Когда закончите работу, деактивируйте:
# deactivate
```

**Каждый раз при запуске активируйте виртуальное окружение:**
```bash
source venv/bin/activate
python3 xray_node.py
```

### Альтернатива: Установка системно (не рекомендуется)

Если нужно установить системно, используйте флаг `--break-system-packages`:

```bash
pip3 install --break-system-packages -r requirements.txt
```

⚠️ **Внимание:** Это может конфликтовать с системными пакетами!

**Подробнее:** См. `INSTALL_DEPS.md` для всех способов установки зависимостей.

### Требуемые пакеты:
- `requests` - для связи с панелью
- `PySocks` - для работы с SOCKS5 прокси
- `Flask` - для API (если используется)
- `pyjwt` - для JWT токенов (если используется)

## Конфигурация ноды

### Основные параметры

```python
# Идентификация ноды
NODE_ID = 'xray-node-001'
NODE_NAME = 'Xray Node'
NODE_HOST = '0.0.0.0'
NODE_PORT = 1080

# Панель управления
PANEL_HOST = '127.0.0.1'
PANEL_PORT = 3333
AUTH_TOKEN = 'node_secret_token_123'

# Xray настройки
XRAY_SOCKS5_HOST = '127.0.0.1'
XRAY_SOCKS5_PORT = 10808
XRAY_MODE = 'socks5'  # 'socks5', 'vmess', 'vless', 'trojan'
```

### Режимы работы

- **`socks5`** - использует Xray как SOCKS5 прокси (самый простой)
- **`vmess`** - требует специальной библиотеки для VMess протокола
- **`vless`** - требует специальной библиотеки для VLESS протокола
- **`trojan`** - требует специальной библиотеки для Trojan протокола
- **`auto`** - автоматическое определение (пока не реализовано)

## Продвинутая настройка Xray

### Использование VMess/VLESS/Trojan как upstream

Если вы хотите использовать Xray с VMess/VLESS/Trojan протоколами, вам нужно:

1. Настроить Xray с соответствующим inbound
2. Настроить Xray с SOCKS5 inbound, который будет проксировать через VMess/VLESS/Trojan outbound

Пример конфигурации:

```json
{
  "inbounds": [
    {
      "port": 10808,
      "protocol": "socks",
      "settings": {
        "auth": "noauth"
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": {
        "vnext": [
          {
            "address": "your-vmess-server.com",
            "port": 443,
            "users": [
              {
                "id": "your-uuid"
              }
            ]
          }
        ]
      }
    }
  ]
}
```

Теперь нода будет проксировать трафик через ваш VMess сервер.

## Мониторинг и логи

Нода логирует:
- Подключения клиентов
- Ошибки подключения
- Статистику трафика
- Heartbeat статус

Пример логов:
```
[XRAY NODE] Прокси-сервер запущен на 0.0.0.0:1080
[XRAY NODE] Трафик проксируется через Xray SOCKS5: 127.0.0.1:10808
[XRAY NODE] Подключение к google.com:443 от 192.168.1.100
[XRAY NODE] Соединение завершено: 5.23s, 102400 bytes
```

## Устранение неполадок

### Ошибка: "PySocks не установлен"
```bash
pip install PySocks
```

### Ошибка: "Не удалось подключиться к Xray"
1. Проверьте, что Xray запущен: `ps aux | grep xray`
2. Проверьте порт: `netstat -an | grep 10808`
3. Проверьте конфигурацию Xray

### Ошибка: "Не удалось зарегистрироваться в панели"
1. Проверьте, что панель запущена
2. Проверьте `PANEL_HOST` и `PANEL_PORT`
3. Проверьте `AUTH_TOKEN`

### Xray не запускается автоматически
1. Проверьте путь к Xray: `which xray`
2. Установите правильный путь в `XRAY_BINARY_PATH`
3. Или установите `AUTO_START_XRAY = False` и запускайте Xray вручную

## Безопасность

- Используйте сильные `AUTH_TOKEN` для связи с панелью
- Настройте firewall для ограничения доступа к ноде
- Используйте TLS/SSL для связи с панелью (если поддерживается)
- Регулярно обновляйте Xray до последней версии

## Производительность

### Оптимизация настроек

В начале файла `xray_node.py` есть настройки для оптимизации работы при большой нагрузке:

```python
# --- НАСТРОЙКИ ПРОИЗВОДИТЕЛЬНОСТИ ---
MAX_CONCURRENT_CONNECTIONS = 500  # Максимальное количество одновременных подключений
CONNECTION_TIMEOUT = 30  # Таймаут подключения в секундах
IDLE_TIMEOUT = 300  # Таймаут простоя соединения в секундах
LOG_CONNECTIONS = False  # Логировать каждое подключение (может замедлять при большой нагрузке)
LOG_DISCONNECTIONS = False  # Логировать завершение соединений
LOG_LEVEL = logging.INFO  # Уровень логирования: DEBUG, INFO, WARNING, ERROR
```

### Рекомендации по настройке:

1. **MAX_CONCURRENT_CONNECTIONS** (по умолчанию: 500)
   - Установите значение в зависимости от ресурсов сервера
   - Для слабых серверов (1-2 CPU, 1-2 GB RAM): 100-200
   - Для средних серверов (2-4 CPU, 4-8 GB RAM): 500-1000
   - Для мощных серверов (4+ CPU, 8+ GB RAM): 1000-5000
   - Если видите ошибки "Превышен лимит подключений", увеличьте это значение

2. **CONNECTION_TIMEOUT** (по умолчанию: 30 секунд)
   - Время ожидания установки соединения
   - Для медленных сетей увеличьте до 60 секунд
   - Для быстрых сетей можно уменьшить до 15-20 секунд

3. **IDLE_TIMEOUT** (по умолчанию: 300 секунд / 5 минут)
   - Время ожидания данных при простаивании соединения
   - Если клиенты часто жалуются на обрывы, увеличьте до 600-900 секунд
   - Для экономии ресурсов можно уменьшить до 120-180 секунд

4. **LOG_CONNECTIONS** (по умолчанию: False)
   - **ВНИМАНИЕ**: При большой нагрузке (сотни подключений в секунду) логирование каждого подключения может значительно замедлить систему
   - Установите `True` только для отладки
   - Для продакшена оставьте `False`

5. **LOG_DISCONNECTIONS** (по умолчанию: False)
   - Логирование завершения соединений также может замедлить систему
   - Используйте только для отладки

6. **LOG_LEVEL** (по умолчанию: logging.INFO)
   - `logging.DEBUG` - все сообщения (для отладки)
   - `logging.INFO` - информационные сообщения (рекомендуется)
   - `logging.WARNING` - только предупреждения и ошибки
   - `logging.ERROR` - только ошибки (максимальная производительность)

### Оптимизация для стабильной работы:

Если вы видите много подключений и нестабильную работу:

1. **Отключите детальное логирование:**
   ```python
   LOG_CONNECTIONS = False
   LOG_DISCONNECTIONS = False
   LOG_LEVEL = logging.WARNING  # или logging.ERROR
   ```

2. **Увеличьте лимит подключений:**
   ```python
   MAX_CONCURRENT_CONNECTIONS = 1000  # или больше, в зависимости от ресурсов
   ```

3. **Настройте таймауты:**
   ```python
   CONNECTION_TIMEOUT = 30  # достаточно для большинства случаев
   IDLE_TIMEOUT = 600  # 10 минут для стабильности
   ```

4. **Проверьте ресурсы сервера:**
   - Убедитесь, что у сервера достаточно RAM и CPU
   - Используйте `htop` или `top` для мониторинга
   - При необходимости ограничьте MAX_CONCURRENT_CONNECTIONS

### Пример конфигурации для высоконагруженной системы:

```python
# Для сервера с 4+ CPU и 8+ GB RAM
MAX_CONCURRENT_CONNECTIONS = 2000
CONNECTION_TIMEOUT = 30
IDLE_TIMEOUT = 600
LOG_CONNECTIONS = False
LOG_DISCONNECTIONS = False
LOG_LEVEL = logging.WARNING
```

### Пример конфигурации для слабой системы:

```python
# Для сервера с 1-2 CPU и 1-2 GB RAM
MAX_CONCURRENT_CONNECTIONS = 100
CONNECTION_TIMEOUT = 45
IDLE_TIMEOUT = 300
LOG_CONNECTIONS = False
LOG_DISCONNECTIONS = False
LOG_LEVEL = logging.ERROR
```

### Мониторинг производительности:

Нода автоматически логирует предупреждения при высокой нагрузке:
- При использовании более 80% лимита подключений вы увидите предупреждение
- Heartbeat отправляется каждые 30 секунд с информацией о количестве активных подключений

### Общие рекомендации:

- Xray очень эффективен и может обрабатывать тысячи соединений
- Используйте несколько нод для балансировки нагрузки
- Мониторьте использование ресурсов через панель управления

## Дополнительные возможности

В будущем можно добавить:
- Поддержку Xray API для динамического управления
- Прямую интеграцию с VMess/VLESS/Trojan протоколами
- Автоматическую балансировку между несколькими Xray серверами
- Мониторинг производительности Xray

## Оптимизация для больших нагрузок

Если к вашей ноде будет подключаться **100-1000+ пользователей одновременно**, обязательно прочитайте:

**📖 [OPTIMIZE_HIGH_LOAD.md](OPTIMIZE_HIGH_LOAD.md)** - Полное руководство по оптимизации для больших нагрузок

Краткие рекомендации:
- Увеличьте `MAX_CONCURRENT_CONNECTIONS` до 2000-3000
- Увеличьте лимит файловых дескрипторов: `ulimit -n 65536`
- Оптимизируйте TCP параметры ядра Linux
- Используйте systemd для управления сервисом с увеличенными лимитами

## Полезные ссылки

- [Xray Документация](https://xtls.github.io/)
- [Xray GitHub](https://github.com/XTLS/Xray-core)
- [Примеры конфигураций](https://github.com/XTLS/Xray-examples)

