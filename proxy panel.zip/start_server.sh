#!/bin/bash

# Скрипт для запуска панели управления прокси

echo "🔍 Проверка занятых портов..."

# Проверяем и освобождаем порты
for port in 3333 8000 8080 8090; do
    pid=$(lsof -ti :$port 2>/dev/null)
    if [ ! -z "$pid" ]; then
        echo "⚠️  Порт $port занят процессом $pid. Останавливаем..."
        kill $pid 2>/dev/null
        sleep 1
    fi
done

echo "✅ Порты освобождены"
echo ""
echo "🚀 Запуск панели управления..."
echo ""

# Запускаем сервер в фоне
python3 panel_server.py > panel_server.log 2>&1 &
SERVER_PID=$!

echo "📝 Сервер запущен (PID: $SERVER_PID)"
echo "📋 Логи: tail -f panel_server.log"
echo ""
echo "Для остановки: kill $SERVER_PID"
echo "Или используйте: ./stop_server.sh"



