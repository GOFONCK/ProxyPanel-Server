#!/bin/bash

# Скрипт для остановки панели управления прокси

echo "🛑 Остановка панели управления..."

# Останавливаем процессы на портах панели
for port in 3333 8000 8080 8090 5000; do
    pid=$(lsof -ti :$port 2>/dev/null)
    if [ ! -z "$pid" ]; then
        echo "Останавливаем процесс $pid на порту $port..."
        kill $pid 2>/dev/null
    fi
done

# Также ищем процессы panel_server.py и web_panel.py
pkill -f "panel_server.py" 2>/dev/null
pkill -f "web_panel.py" 2>/dev/null

sleep 2

echo "✅ Все процессы остановлены"



